def display_board(board):
    #print('\n'*100)
    print(board[1]+'|'+board[2]+'|'+board[3])
    print(board[4]+'|'+board[5]+'|'+board[6])
    print(board[7]+'|'+board[8]+'|'+board[9])

def player1_input():
    p = ''
    while p not in ['X', 'O']:
        p = input('Do you want to be X or O? ')
    return p

def player2_input(var):
    q = ''
    if var == 'X':
        q = 'O'
    else:
        q = 'X'
    return q
    

def place_marker(board, marker, position):
    while not(1 <= position <= 9):
        input('Please position should be in range (0,9)?  ')
    board[position] = marker

def win_check(board, mark):
    if ((board[1] == board[2] == board[3] == mark) or (board[4] == board[5] == board[6] == mark)
    or (board[7] == board[8] == board[9] == mark) or (board[1] == board[4] == board[7] == mark)
    or (board[2] == board[5] == board[8] == mark) or (board[3] == board[6] == board[9] == mark)
    or (board[1] == board[5] == board[9] == mark) or (board[3] == board[5] == board[7] == mark)):
        return True
    return False

import random
def choose_first():
    random_choice = random.randint(1,10)
    if random_choice % 2 == 0:
        print('Player 1 goes First')
    else:
        print('Player 2 goes First')

        
def space_check(board, position):
    if board[position] == ' ':
        return True
    return False


def full_board_check(board):
    for number in range(1,10):
        while board[number] == ' ':
            return False
    return True

def player_choice(board):
            position = int(input('Where would you like to play: '))
            if 1 <= position <= 9:
                while board[position] != ' ':
                    p = int(input('Different number please '))
                    position = p
                return position

        
 #   position = int(input('Where would you like to play: '))
 #   if 1 <= position <= 9:
 #       while board[position] != ' ':
 #           p = int(input('Different number please '))
  #          position = p
        #return position
            
    #else:
        #print('invalid shit nigga')
    #if res == True:
        #return position
    #else:
        #print ('invalid selection')

def replay():
    answer = ''
    while answer not in ['Y', 'N']:
        answer = input('Do you want to play again? Y for Yes and N for No? ')
    if answer is 'Y':
        return True
    return False

def tic_tac_toe():
    print('Welcome to Tic Tac Toe')
    test_board = [' ']*10
    choose_first()
    var = player1_input()
    var2 = player2_input(var)
    display_board(test_board)
    while full_board_check(test_board) != True:
        q = True
        while q == True:
            position = player_choice(test_board)
            place_marker(test_board, var, position)
            display_board(test_board)
           # q = False
            if win_check(test_board, var) == True:
                return ('You,ve won')
            q = False
        else:
            position = player_choice(test_board)
            place_marker(test_board, var2, position)
            display_board(test_board)
           #q = True
            if win_check(test_board, var2) == True:
                return ('You,ve won')
            q = True
    else:
        print ('game is a draw')
    









def workin_func():
    while full_board_check(test_board) == False:
        q = True
        while q == True:
            position = player_choice(test_board)
            place_marker(test_board, var, position)
            display_board(test_board)
            q = False
            if win_check(test_board, var) == True:
                return ('You,ve won')
            s = full_board_check(test_board)
            print (s)
        else:
            position = player_choice(test_board)
            place_marker(test_board, var2, position)
            display_board(test_board)
            q = True
            if win_check(test_board, var) == True:
                return ('You,ve won')
            s = full_board_check(test_board)
            print (s)
    else:
        return ('game is a draw')
            
            
        
    
    
    
    

    
